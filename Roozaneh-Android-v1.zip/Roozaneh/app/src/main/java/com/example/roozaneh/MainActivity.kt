package com.example.roozaneh

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

data class Task(
    val id: Int,
    val title: String,
    val category: String,
    val time: String,
    val priority: Int,
    val done: Boolean = false
)

private val Accent = Color(0xFF6750A4)
private val Pink = Color(0xFFE95D9E)
private val Orange = Color(0xFFFF9F43)
private val Green = Color(0xFF43A047)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoozanehApp() }
    }
}

@Composable
fun RoozanehApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var tasks by remember {
        mutableStateOf(
            listOf(
                Task(1, "پیاده‌روی ۳۰ دقیقه‌ای", "ورزش", "07:30", 2),
                Task(2, "بررسی ایمیل‌ها", "کار", "09:00", 3),
                Task(3, "مطالعه کتاب", "مطالعه", "18:00", 1),
                Task(4, "خرید روزانه", "شخصی", "20:00", 2)
            )
        )
    }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent,
            secondary = Pink,
            tertiary = Orange,
            background = Color(0xFFFFF8FC),
            surface = Color.White
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Color(0xFFFFF8FC),
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        val items = listOf(
                            Icons.Default.Home to "خانه",
                            Icons.Default.CheckCircle to "کارها",
                            Icons.Default.CalendarMonth to "تقویم",
                            Icons.Default.BarChart to "آمار",
                            Icons.Default.Settings to "تنظیمات"
                        )
                        items.forEachIndexed { i, item ->
                            NavigationBarItem(
                                selected = selectedTab == i,
                                onClick = { selectedTab = i },
                                icon = { Icon(item.first, contentDescription = item.second) },
                                label = { Text(item.second) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { showAdd = true },
                        containerColor = Accent,
                        contentColor = Color.White
                    ) { Icon(Icons.Default.Add, "افزودن") }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (selectedTab) {
                        0 -> HomeScreen(tasks, onToggle = { id ->
                            tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
                        })
                        1 -> TasksScreen(tasks, onToggle = { id ->
                            tasks = tasks.map { if (it.id == id) it.copy(done = !it.done) else it }
                        })
                        2 -> CalendarScreen(tasks)
                        3 -> StatsScreen(tasks)
                        4 -> SettingsScreen()
                    }
                }
            }

            if (showAdd) {
                AddTaskDialog(
                    onDismiss = { showAdd = false },
                    onAdd = { title, category, time, priority ->
                        val next = (tasks.maxOfOrNull { it.id } ?: 0) + 1
                        tasks = tasks + Task(next, title, category, time, priority)
                        showAdd = false
                    }
                )
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        subtitle?.let {
            Spacer(Modifier.height(4.dp))
            Text(it, color = Color.Gray, fontSize = 14.sp)
        }
    }
}

@Composable
fun HomeScreen(tasks: List<Task>, onToggle: (Int) -> Unit) {
    val done = tasks.count { it.done }
    val progress = if (tasks.isEmpty()) 0f else done.toFloat() / tasks.size

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().height(190.dp)
                    .background(
                        Brush.linearGradient(listOf(Accent, Pink, Orange)),
                        RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)
                    )
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("روزت رو بساز ✨", color = Color.White, fontSize = 17.sp)
                    Text(
                        "سلام! آماده‌ای امروز رو عالی پیش ببری؟",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Spacer(Modifier.height(18.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
                        color = Color.White,
                        trackColor = Color.White.copy(alpha = .3f)
                    )
                    Text("$done از ${tasks.size} کار انجام شده", color = Color.White, modifier = Modifier.padding(top = 7.dp))
                }
            }
        }
        item { Header("کارهای امروز", "کارهای مهمت رو یکی‌یکی جلو ببر") }
        items(tasks.filter { !it.done }.take(5), key = { it.id }) { task ->
            TaskCard(task, onToggle)
        }
        item {
            if (tasks.any { it.done }) {
                Header("انجام‌شده‌ها")
            }
        }
        items(tasks.filter { it.done }, key = { it.id }) { task ->
            TaskCard(task, onToggle)
        }
    }
}

@Composable
fun TasksScreen(tasks: List<Task>, onToggle: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("همه کارها", "${tasks.size} کار")
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(tasks, key = { it.id }) { TaskCard(it, onToggle) }
        }
    }
}

@Composable
fun TaskCard(task: Task, onToggle: (Int) -> Unit) {
    val priorityColor = when (task.priority) {
        3 -> Color(0xFFE53935)
        2 -> Orange
        else -> Green
    }
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = task.done,
                onCheckedChange = { onToggle(task.id) }
            )
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(
                    task.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (task.done) Color.Gray else Color.Unspecified
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(task.category, color = Accent, fontSize = 12.sp)
                    Text("  •  ${task.time}", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Box(
                Modifier.size(10.dp).clip(CircleShape).background(priorityColor)
            )
        }
    }
}

@Composable
fun CalendarScreen(tasks: List<Task>) {
    Header("تقویم", "برنامه‌ریزی روزانه، هفتگی و ماهانه")
    Column(Modifier.padding(horizontal = 16.dp)) {
        Card(shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("امروز", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    SimpleDateFormat("EEEE، d MMMM yyyy", Locale("fa")).format(Date()),
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 5.dp)
                )
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach {
                        Text(it, modifier = Modifier.padding(5.dp), fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("کارهای امروز: ${tasks.size}", color = Accent, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("نماها", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ماهانه", "هفتگی", "روزانه").forEach {
                AssistChip(onClick = {}, label = { Text(it) })
            }
        }
    }
}

@Composable
fun StatsScreen(tasks: List<Task>) {
    val done = tasks.count { it.done }
    val percent = if (tasks.isEmpty()) 0 else done * 100 / tasks.size
    Column(Modifier.fillMaxSize()) {
        Header("آمار و گزارش", "نگاهی سریع به عملکردت")
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatCard("پیشرفت", "$percent٪", Accent, Modifier.weight(1f))
            StatCard("انجام‌شده", "$done", Green, Modifier.weight(1f))
            StatCard("باقی‌مانده", "${tasks.size - done}", Orange, Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("روند هفتگی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth().height(130.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    listOf(0.35f, 0.55f, 0.7f, 0.45f, 0.85f, 0.65f, percent / 100f).forEachIndexed { i, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.width(22.dp).fillMaxHeight(v.coerceIn(.05f, 1f))
                                    .clip(RoundedCornerShape(10.dp)).background(
                                        Brush.verticalGradient(listOf(Pink, Accent))
                                    )
                            )
                            Text(listOf("ش", "ی", "د", "س", "چ", "پ", "ج")[i], fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize()) {
        Header("تنظیمات")
        val rows = listOf(
            "اعلان‌ها" to Icons.Default.Notifications,
            "تقویم شمسی / میلادی" to Icons.Default.CalendarMonth,
            "پشتیبان‌گیری" to Icons.Default.Backup,
            "ظاهر برنامه" to Icons.Default.Palette,
            "مدیریت دسته‌بندی‌ها" to Icons.Default.Label,
            "درباره روزانه" to Icons.Default.Info
        )
        rows.forEach { (title, icon) ->
            ListItem(
                headlineContent = { Text(title) },
                leadingContent = { Icon(icon, null, tint = Accent) },
                trailingContent = { Icon(Icons.Default.ChevronLeft, null) },
                modifier = Modifier.clickable {}
            )
            HorizontalDivider(Modifier.padding(horizontal = 16.dp))
        }
    }
}

@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("شخصی") }
    var time by remember { mutableStateOf("09:00") }
    var priority by remember { mutableIntStateOf(2) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن کار جدید") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان کار") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("دسته‌بندی") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("ساعت") },
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))
                Text("اولویت", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1 to "کم", 2 to "متوسط", 3 to "زیاد").forEach { (v, label) ->
                        FilterChip(
                            selected = priority == v,
                            onClick = { priority = v },
                            label = { Text(label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank()) onAdd(title, category, time, priority) }
            ) { Text("افزودن") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
